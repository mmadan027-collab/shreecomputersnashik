# Shree Computers Website

This is a simple static website for a computer shop, built with TailwindCSS and HTML.

## How to Deploy on GitHub Pages
1. Create a new repository on GitHub.
2. Upload the files from this ZIP.
3. Go to Settings > Pages > Source: `main` branch, folder: `/ (root)`.
4. Save and your site will be live.
